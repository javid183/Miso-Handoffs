using System.Linq;
using MISO.Core.Systems.AbilitySystem.Abilities;
using MISO.Core.Systems.AbilitySystem.Effects;
using MISO.Core.Units;
using UnityEditor;
using UnityEngine;

namespace MISO.Core.Features.Onboarding.EditorTools
{
    // Mark at the stone. He is placed in the level by the build (he is not a roster seat) and stays on his tile all
    // level: a target for the enemies, never a unit the player plays. Everything here is set on the level's
    // instance; his prefab is untouched.
    // - Held from the level start by HoldUnitsUntilSignal (the inactive tag the player controller skips), and
    //   nothing in the level releases him.
    // - Unmovable and unable to swap, so pushes, pulls and swaps leave him on his tile.
    // - Ignored by objectives, so the template's defeat (no Bergson standing) still means "no sister standing": a
    //   held unit isn't one the player can stand with. His own defeat is the second defeat group.
    // - His Family Role answers no phase, so it never fires, and his role zone isn't drawn. The inactive tag alone
    //   doesn't stop a role: the role's only gates are its phase, its trigger events and the family points.
    // - His Duos with the sisters are locked (WireLocks), so no Duo moves him off the stone.
    public static partial class MissionWiringHoldTheYard
    {
        public const string MarkHoldName = "Mark on the stone";

        /// <summary>The persistent tags Mark's instance carries in this level.</summary>
        public static readonly string[] MarkTags = { "EntityState.Unmovable", "EntityState.Unable to Swap", "EntityState.IgnoreObjective" };

        private static GUnit WireMark(GameObject root)
        {
            var marks = root.GetComponentsInChildren<GUnit>(true).Where(u => u.name == MarkUnitName).ToList();
            if (marks.Count != 1) throw new System.InvalidOperationException($"Hold the yard expects one Mark (from the build), found {marks.Count}.");
            var mark = marks[0];
            if (TileOf(mark) != MarkTile) throw new System.InvalidOperationException($"Mark stands on {TileOf(mark)}, not {MarkTile}.");

            using (var so = new SerializedObject(mark))
            {
                foreach (var id in MarkTags) EnsurePersistentTag(so, id);
                so.ApplyModifiedPropertiesWithoutUndo();
            }
            SwitchOffFamilyRole(mark);
            WireHold(root, mark);
            return mark;
        }

        private static void EnsurePersistentTag(SerializedObject unit, string id)
        {
            var entries = unit.FindProperty("tagSet.tagEntries");
            SerializedProperty entry = null;
            for (var i = 0; i < entries.arraySize && entry == null; i++)
                if (entries.GetArrayElementAtIndex(i).FindPropertyRelative("gTag.entityID").stringValue == id)
                    entry = entries.GetArrayElementAtIndex(i);
            if (entry == null)
            {
                entries.arraySize++;
                entry = entries.GetArrayElementAtIndex(entries.arraySize - 1);
                entry.FindPropertyRelative("gTag.entityID").stringValue = id;
            }
            entry.FindPropertyRelative("lifeTurns").intValue = -1;
            entry.FindPropertyRelative("tagPresenceMode").intValue = (int)GTagPresenceMode.Persistent;
        }

        private static void SwitchOffFamilyRole(GUnit mark)
        {
            var handler = mark.GetComponentsInChildren<FactionRoleHandlerBase>(true).SingleOrDefault();
            if (!handler) throw new System.InvalidOperationException("Mark has no Family Role handler.");
            using var so = new SerializedObject(handler);
            so.FindProperty("activationPhase").intValue = 0;
            so.FindProperty("showRoleZone").boolValue = false;
            so.ApplyModifiedPropertiesWithoutUndo();
        }

        // One hold, on its own object under the level, holding Mark from the level start.
        private static void WireHold(GameObject root, GUnit mark)
        {
            var holds = root.GetComponentsInChildren<HoldUnitsUntilSignal>(true);
            var hold = holds.FirstOrDefault(h => h.name == MarkHoldName);
            foreach (var other in holds.Where(h => h != hold)) Object.DestroyImmediate(other);
            if (!hold)
            {
                var go = new GameObject(MarkHoldName);
                go.transform.SetParent(root.transform, false);
                hold = go.AddComponent<HoldUnitsUntilSignal>();
            }
            hold.Set(new[] { mark }, true);
            EditorUtility.SetDirty(hold);
        }
    }
}
