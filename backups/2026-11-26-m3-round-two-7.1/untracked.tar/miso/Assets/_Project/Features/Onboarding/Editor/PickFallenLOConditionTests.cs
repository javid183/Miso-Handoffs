using System.Collections.Generic;
using MISO.Core.Units;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace MISO.Core.Features.Onboarding.EditorTests
{
    // The condition that is true once the squad's free pick has fallen: the pick is the first family unit that
    // isn't a fixed roster seat; a sister falling doesn't count, and with no fixed seat there is no pick.
    public class PickFallenLOConditionTests
    {
        private static GUnit NamedUnit(string nickname)
        {
            var go = new GameObject(nickname);
            go.SetActive(false);
            var unit = go.AddComponent<GUnit>();
            using var so = new SerializedObject(unit);
            so.FindProperty("title").stringValue = nickname;
            so.ApplyModifiedPropertiesWithoutUndo();
            return unit;
        }

        [Test]
        public void ThePickFallingHoldsAndASisterFallingDoesNot()
        {
            var linda = NamedUnit("Linda");
            var lucy = NamedUnit("Lucy");
            var pick = NamedUnit("John");
            try
            {
                var units = new[] { linda, lucy, pick };
                var seats = new HashSet<string> { "Linda", "Lucy" };
                var alive = new HashSet<GUnit>(units);
                var watch = new PickFallenLOCondition.PickWatch();

                Assert.IsFalse(watch.Observe(units, seats, alive.Contains), "the pick is found, standing");
                alive.Remove(lucy);
                Assert.IsFalse(watch.Observe(units, seats, alive.Contains), "a sister fell: the condition doesn't hold");
                alive.Remove(pick);
                Assert.IsTrue(watch.Observe(units, seats, alive.Contains), "the pick fell");
            }
            finally
            {
                Object.DestroyImmediate(linda.gameObject);
                Object.DestroyImmediate(lucy.gameObject);
                Object.DestroyImmediate(pick.gameObject);
            }
        }

        [Test]
        public void WithNoFixedSeatThereIsNoPick()
        {
            var a = NamedUnit("Linda");
            var b = NamedUnit("John");
            try
            {
                var alive = new HashSet<GUnit> { a, b };
                var watch = new PickFallenLOCondition.PickWatch();
                var seats = new HashSet<string>();
                Assert.IsFalse(watch.Observe(new[] { a, b }, seats, alive.Contains));
                alive.Clear();
                Assert.IsFalse(watch.Observe(new[] { a, b }, seats, alive.Contains), "a sandbox run never holds");
            }
            finally
            {
                Object.DestroyImmediate(a.gameObject);
                Object.DestroyImmediate(b.gameObject);
            }
        }

        [Test]
        public void APickNotYetSeenDoesNotHold()
        {
            var linda = NamedUnit("Linda");
            try
            {
                var watch = new PickFallenLOCondition.PickWatch();
                var seats = new HashSet<string> { "Linda", "Lucy" };
                Assert.IsFalse(watch.Observe(new[] { linda }, seats, _ => true), "only fixed seats on the board: no pick yet");
            }
            finally { Object.DestroyImmediate(linda.gameObject); }
        }
    }
}
