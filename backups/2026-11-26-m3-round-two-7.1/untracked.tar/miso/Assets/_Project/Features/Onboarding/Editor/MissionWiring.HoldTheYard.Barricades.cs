using System.Collections.Generic;
using System.IO;
using System.Linq;
using MISO.Core.Systems.GridSystem;
using MISO.Core.Units;
using UnityEditor;
using UnityEngine;

namespace MISO.Core.Features.Onboarding.EditorTools
{
    // The barricades that close the two necks into the yard. A barricade is a variant of the rock unit: neutral,
    // unmovable, unswappable, no abilities, the unit health bar the rock already has. Its own base health is the
    // barricade's health. Neutral is never scaled by the enemy tier (the tier only touches factions hostile to the
    // family), so every barricade has that health in any level. In this level Neutral is hostile to the enemies, so
    // the goblins can't walk through a barricade and attack it, and allied to the family, so the family walks
    // through it (without stopping on it) and never targets it.
    public static partial class MissionWiringHoldTheYard
    {
        public const string BarricadePrefabPath = StoneFolder + "/Unit_Barricade.prefab";
        public const string BarricadeUnitName = "Unit_Barricade";
        public const string BarricadeNickname = "Barricade";
        public const float BarricadeHealth = 8f;

        // Creates the variant when missing; sets its title and health otherwise (saved only on a change).
        private static GameObject EnsureBarricadePrefab()
        {
            var rock = AssetDatabase.LoadAssetAtPath<GameObject>(RockPrefabPath);
            if (!rock) throw new FileNotFoundException("The rock unit is missing (The Ridge's wiring creates it): " + RockPrefabPath);
            if (!File.Exists(BarricadePrefabPath))
            {
                var instance = (GameObject)PrefabUtility.InstantiatePrefab(rock);
                try
                {
                    instance.name = BarricadeUnitName;
                    ApplyBarricade(instance);
                    PrefabUtility.SaveAsPrefabAsset(instance, BarricadePrefabPath, out var saved);
                    if (!saved) throw new IOException("Could not save " + BarricadePrefabPath);
                }
                finally
                {
                    Object.DestroyImmediate(instance);
                }
            }
            else
            {
                var contents = PrefabUtility.LoadPrefabContents(BarricadePrefabPath);
                try
                {
                    if (ApplyBarricade(contents)) PrefabUtility.SaveAsPrefabAsset(contents, BarricadePrefabPath);
                }
                finally
                {
                    PrefabUtility.UnloadPrefabContents(contents);
                }
            }
            return AssetDatabase.LoadAssetAtPath<GameObject>(BarricadePrefabPath);
        }

        // Returns whether anything changed.
        private static bool ApplyBarricade(GameObject barricade)
        {
            var unit = barricade.GetComponent<GUnit>();
            using var so = new SerializedObject(unit);
            var changed = false;
            var title = so.FindProperty("title");
            if (title.stringValue != BarricadeNickname)
            {
                title.stringValue = BarricadeNickname;
                changed = true;
            }
            var health = BaseHealth(so);
            if (health == null) throw new System.InvalidOperationException("The rock has no health attribute backed by " + HealthStatId);
            if (!Mathf.Approximately(health.floatValue, BarricadeHealth))
            {
                health.floatValue = BarricadeHealth;
                changed = true;
            }
            if (changed) so.ApplyModifiedPropertiesWithoutUndo();
            return changed;
        }

        /// <summary>
        /// The unit's base health: the factor of the attribute whose default reads the health stat (the Dark Claw's
        /// is 16, the rock's 1). The health stat's own factor multiplies it.
        /// </summary>
        public static SerializedProperty BaseHealth(SerializedObject unit)
        {
            var entries = unit.FindProperty("attributeSet.attributeEntries");
            for (var i = 0; i < entries.arraySize; i++)
            {
                var value = entries.GetArrayElementAtIndex(i).FindPropertyRelative("defaultSbValue");
                if (value.FindPropertyRelative("attributeReference.entityID").stringValue == HealthStatId)
                    return value.FindPropertyRelative("baseFactor");
            }
            return null;
        }

        // One barricade on each neck tile. An instance of the barricade prefab already on its tile is reused; any
        // other instance is removed.
        private static void PlaceBarricades(GameObject root, GameObject prefab)
        {
            var instances = BarricadeInstances(root, prefab);
            var kept = new HashSet<GUnit>();
            foreach (var tile in BarricadeTiles)
            {
                var cell = CellAt(root, tile);
                var unit = instances.FirstOrDefault(u => !kept.Contains(u) && u.GetComponentInParent<GridCell>(true) == cell);
                if (!unit)
                {
                    var go = (GameObject)PrefabUtility.InstantiatePrefab(prefab, OccupantRoot(cell));
                    unit = go.GetComponent<GUnit>();
                }
                unit.transform.position = GridPluggableEntity.Centroid(new List<GridCell> { cell });
                unit.gameObject.SetActive(true);
                kept.Add(unit);
            }
            foreach (var extra in instances.Where(u => !kept.Contains(u)))
                Object.DestroyImmediate(extra.gameObject);
        }

        /// <summary>The level's instances of the barricade prefab.</summary>
        public static List<GUnit> BarricadeInstances(GameObject root, GameObject barricadePrefab) =>
            root.GetComponentsInChildren<GUnit>(true)
                .Where(u => PrefabUtility.IsOutermostPrefabInstanceRoot(u.gameObject)
                            && PrefabUtility.GetCorrespondingObjectFromSource(u.gameObject) == barricadePrefab)
                .ToList();
    }
}
