using MISO.Core.Units;
using NUnit.Framework;

namespace MISO.Core.Features.Onboarding.EditorTests
{
    // The "hold from level start" option: the units are held before the first turn and stay held through every turn
    // end; with the option off, the level start changes nothing and the old timing stands.
    public partial class HoldUnitsUntilSignalTests
    {
        private HoldUnitsUntilSignal MakeHoldFromStart(params GUnit[] held)
        {
            var hold = MakeHold(held);
            hold.Set(held, true);
            return hold;
        }

        [Test]
        public void TheOptionIsOffByDefault()
        {
            Assert.IsFalse(MakeHold(MakeUnit("Linda")).HoldFromLevelStart);
        }

        [Test]
        public void WithTheOptionOnTheLevelStartHoldsTheUnits()
        {
            var mark = MakeUnit("Mark");
            var hold = MakeHoldFromStart(mark);
            Assert.IsTrue(hold.HoldFromLevelStart);

            hold.NotifyLevelStarting();
            Assert.IsTrue(hold.Holding);
            Assert.IsTrue(HoldUnitsUntilSignal.HasHoldTag(mark));
            Assert.AreEqual(1, TagCount(mark));

            hold.NotifyLevelStarting();
            Assert.AreEqual(1, TagCount(mark), "Start and the level-started event both arrive: one tag");
        }

        [Test]
        public void WithTheOptionOffTheLevelStartChangesNothing()
        {
            var linda = MakeUnit("Linda");
            var hold = MakeHold(linda);

            hold.NotifyLevelStarting();
            Assert.IsFalse(hold.Holding);
            Assert.IsFalse(HoldUnitsUntilSignal.HasHoldTag(linda));

            hold.NotifyTurnStarted(true);
            Assert.IsFalse(hold.Holding, "the family's own turn start doesn't hold either");
            hold.NotifyTurnEnded(false);
            Assert.IsTrue(hold.Holding, "the old timing: another faction's turn end");
        }

        // The family moves first: the hold is in place when its first turn starts, so it took that turn's points.
        [Test]
        public void HeldFromTheStartTheFirstOwnTurnStartsHeld()
        {
            var mark = MakeUnit("Mark");
            var hold = MakeHoldFromStart(mark);
            hold.NotifyLevelStarting();

            hold.NotifyTurnStarted(true);
            Assert.IsTrue(hold.OwnTurnOpen);
            Assert.IsTrue(hold.HeldAtOwnTurnStart);
        }

        [Test]
        public void HeldFromTheStartNoTurnEndLetsGo()
        {
            var mark = MakeUnit("Mark");
            var hold = MakeHoldFromStart(mark);
            hold.NotifyLevelStarting();

            for (var round = 0; round < 6; round++)
            {
                hold.NotifyTurnStarted(true);
                hold.NotifyTurnEnded(true);
                hold.NotifyTurnStarted(false);
                hold.NotifyTurnEnded(false);
            }

            Assert.IsTrue(hold.Holding);
            Assert.IsFalse(hold.Released);
            Assert.AreEqual(1, TagCount(mark));
        }

        // Missing the level start (a component that woke late) still holds from the first turn start on.
        [Test]
        public void HeldFromTheStartAMissedStartIsCaughtAtTheFirstTurnStart()
        {
            var mark = MakeUnit("Mark");
            var hold = MakeHoldFromStart(mark);

            hold.NotifyTurnStarted(true);
            Assert.IsTrue(hold.Holding);
            Assert.IsTrue(hold.HeldAtOwnTurnStart);
            Assert.IsTrue(HoldUnitsUntilSignal.HasHoldTag(mark));
        }

        [Test]
        public void HeldFromTheStartOnlyAReleaseLetsGo()
        {
            var mark = MakeUnit("Mark");
            var hold = MakeHoldFromStart(mark);
            hold.NotifyLevelStarting();

            hold.Release();
            Assert.IsFalse(hold.Holding);
            Assert.IsFalse(HoldUnitsUntilSignal.HasHoldTag(mark));
            hold.NotifyLevelStarting();
            hold.NotifyTurnStarted(true);
            Assert.IsFalse(hold.Holding, "a released hold doesn't come back in the same level");
        }
    }
}
